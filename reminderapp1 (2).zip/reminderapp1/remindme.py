import tkinter as tk
from tkinter import messagebox
from tkinter import PhotoImage
import reminder_manager

class ReminderApp(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title("Reminder Application")
        self.geometry("400x350")

        self.create_widgets()

    # Create widgets in the main window
    def create_widgets(self):
        # Labels
        self.title_label = tk.Label(self, text="Reminder Application", font=("Arial", 16)) # Creates a label with the text "Reminder Application" and font Arial, size 16
        self.title_label.pack(pady=20)

        self.reminder_label = tk.Label(self, text="Enter reminder:") # Creates a label with the text "Enter reminder:"
        self.reminder_label.pack()

        self.validation_label = tk.Label(self, text="Reminder cannot contain special characters like '<', '>'", fg="red") # Creates a label with the text "Reminder cannot contain special characters like '<', '>'" and text color red
        self.validation_label.pack()

        # Entry box for reminder input
        self.reminder_entry = tk.Entry(self, width=50) # Creates an entry box with width 50
        self.reminder_entry.pack(padx=10, pady=10)

        # Buttons
        self.add_icon = tk.PhotoImage(file="addicon.png").subsample(5, 5) # Creates an image object from the addicon.png file and scales it down by a factor of 5
        self.add_button = tk.Button(self, text="Add Reminder", command=self.add_reminder, image=self.add_icon, compound=tk.TOP) # Creates a button with the text "Add Reminder", calls the add_reminder function when clicked, and displays the add_icon image on the button
        self.add_button.pack(side=tk.LEFT)

        self.view_icon = tk.PhotoImage(file="viewicon.png").subsample(5, 5) # Creates an image object from the viewicon.png file and scales it down by a factor of 5
        self.view_button = tk.Button(self, text="View Reminders", command=self.view_reminders, image=self.view_icon, compound=tk.TOP) # Creates a button with the text "View Reminders", calls the view_reminders function when clicked, and displays the view_icon image on the button
        self.view_button.pack(side=tk.RIGHT)

        self.exit_button = tk.Button(self, text="Exit", command=self.exit_app) # Creates a button with the text "Exit", calls the exit_app function when clicked
        self.exit_button.pack(side=tk.BOTTOM, padx=5)

    # Function for adding reminder
    def add_reminder(self):
        reminder = self.reminder_entry.get() # Gets the text from the entry box

        # Check for invalid characters
        if not reminder or any(char in reminder for char in "<>"):
            messagebox.showerror("Error", "Reminder cannot be empty or contain special characters like '<', '>'!")
            return

        reminder_manager.add_reminder(reminder)

        self.reminder_entry.delete(0, tk.END)
        messagebox.showinfo("Success", "Reminder added successfully!")

    # Function for viewing reminders
    def view_reminders(self):
        self.reminders_window = RemindersWindow(self) # Creates a new window for viewing reminders

    # Function for exiting the application
    def exit_app(self):
        if messagebox.askyesno("Exit", "Are you sure you want to exit?"):
            self.destroy()

class RemindersWindow(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)

        self.title("Reminders")
        self.geometry("400x300")

        self.create_widgets()

    # Create widgets in the reminders window
    def create_widgets(self):
        # Labels
        self.title_label = tk.Label(self, text="Reminders", font=("Arial", 16)) # Creates a label with the text "Reminders" and font Arial, size 16
        self.title_label.pack(pady=20)

        # Text box for displaying reminders
        self.reminders_text = tk.Text(self, wrap=tk.WORD, height=10, width=50) # Creates a text box with word wrapping, height 10, and width 50
        self.reminders_text.pack(padx=10, pady=10)

        # Button for closing the window
        self.close_button = tk.Button(self, text="Close", command=self.destroy) # Creates a button with the text "Close", calls the destroy function when clicked
        self.close_button.pack(pady=5)

        self.load_reminders()

    # Load reminders from the file
    def load_reminders(self):
        reminders = reminder_manager.load_reminders() # Gets the list of reminders from the file

        for reminder in reminders:
            self.reminders_text.insert(tk.END, reminder + '\n')

if __name__ == "__main__":
    app = ReminderApp() # Creates an instance of the ReminderApp class
    app.mainloop()
