import os
from datetime import datetime

REMINDERS_FILE = "reminders.txt"

def add_reminder(reminder):
    with open(REMINDERS_FILE, "a") as f:
        f.write(f"{datetime.now()} - {reminder}\n")

def load_reminders():
    if not os.path.exists(REMINDERS_FILE):
        return []
    
    with open(REMINDERS_FILE, "r") as f:
        reminders = [line.strip() for line in f.readlines()]

    return reminders